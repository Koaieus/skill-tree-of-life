# Handoff: Circuit-Fan Node Tooltip

## Overview
The hover/select tooltip for a skill-tree node in *Skill Tree of Life* (Godot 4.4). Six info
panels — Granted Modifiers, Hostile Owner (radar chart), Addons, Node-Local loot, Core
manifest, ID chip — fan out from the node in a circuit-board-style choreography: a trace line
draws in from the node to each panel, then the panel itself unfurls at the trace's tip. This is
a **structural exploration file**: nearly every aspect of the fan (orientation, trace routing,
timing, skins) is a swappable parameter, because the "final" combination hasn't been locked yet.

## About the design files
`CircuitFanTooltip.dc.html` and its test bench `Circuit Fan Tooltip Lab.dc.html` are **HTML
design references**, not production code. They exist to let us converge on choreography and
layout by twirling parameters live, in a browser. The task is to **recreate the chosen look in
Godot** (`Control`/`Node2D` scenes, `Tween`/`AnimationPlayer`, GDScript) using the project's
existing tooltip/UI conventions — not to port the DOM, CSS, or JS.

**Read `EXPORT_NOTES_Godot.md` (project root) first** — it documents what carries over
conceptually vs. what is an HTML-only trick with no Godot equivalent. This README covers the
same ground specifically for the tooltip's current settled state; treat the two as one packet.

## Fidelity
High-fidelity for **visual language** (panel skin, typography, color, glow) and **choreography
concepts** (per-unit independence, trace-then-panel sequencing, constant-brightness loop). Low//
exploratory for **exact routing geometry** — trace-path math is still being tuned via
`traceStyle`/`sprout`/`traceBend`, so treat the current default combo as "a good current
answer," not a locked spec. Confirm the winning combo with design before final GDScript pass.

---

## Look & feel

**Read as:** a hostile/enemy node's intel readout — a circuit board lighting up, terminal-glass
panels snapping into place at the end of glowing traces. Cold, technical, slightly hostile (red
owner accent against the node's own color).

- **Fonts:** `Cinzel` 700/800 for the owner name, level line, CORE badge, class name (arcane
  display serif). `Chakra Petch` 400–700 for every number, tag, and label (techy/tabular). Both
  Google Fonts — substitute the nearest licensed equivalents in Godot (e.g. a serif display face
  + a monospace/technical sans), don't ship the literal font files without checking license.
- **Panel skins** (`panelSkin`, 3 options): `glass` (default reference look) — near-black
  gradient `linear-gradient(158deg, rgba(20,23,34,.86), rgba(9,10,17,.93))`, 1px border at 50%
  alpha of the arc color, `border-radius:11px`, `backdrop-filter: blur(9px)`, drop shadow
  `0 12px 32px -14px rgba(0,0,0,.9)` plus a color-glow shadow scaling with `glow`. `hologram` —
  thin scanline texture (`repeating-linear-gradient` every 4px) over a darker teal-leaning
  gradient, no blur-glass warmth — reads more sci-fi/diagnostic. `solid` — flat `#0d1119`,
  sharper `border-radius:8px`, no backdrop blur — cheapest/most "in-game HUD" reading.
- **Accent color system:** every panel derives its glow/border hue from `archColor` (the node
  owner's color, hex → OKLCH hue internally) — panels are NOT individually colored except Owner
  (fixed red-ish, hostile) and Core (fixed gold, "the core is always gold" regardless of owner).
  Modifier-row colors come from a fixed 5-slot operator palette (base/percent/multiply/bonus/set)
  independent of owner color — that palette is the semantic "kind of number" language and should
  stay constant across nodes.
- **Glow scales with a single `glow` 0–1 slider**: bigger glow = larger blur radius + stronger
  shadow opacity, not a different color. In Godot terms: one exported float driving a
  `CanvasItem` glow/blur param or a shader uniform, not per-skin hardcoded shadow values.
- **Traces:** thin (1.3–2.3px) glowing lines in the owner's hue; a bright traveling "tip" spark
  leads the draw-in, then the line settles to a dimmer steady-lit state and (optionally) idles
  with a looping spark or pulse (`traceIdleAnim`). The idle state is a *steady-lit wire*, not a
  return to "off" — a big fixed bug class we chased was the line going dark between loop cycles;
  the settled rule is **constant brightness across in → loop → out**, achieved by never handing
  the line off to a dimmer "rest" style mid-loop.
- **HP surfacing** is a placement choice (`hpPlacement`: ring around the node / header row inside
  the Stats panel / floating chip above the node / small pill chip) — same bar widget, four
  anchor points. Treat as one reusable "HP readout" component with a position enum, not four
  different widgets.

## Layout & composition
- **912×664 reference canvas**, node roughly centered, six panels fanned around it.
- **Two structural families**, selected by `fanOrient`:
  - `radial` — panels ring the node symmetrically (stats above, owner/addons upper corners,
    local/core lower corners, id below) — a classic radial tooltip burst.
  - `up` / `down` — a **tech-tree "fruit on a branch" composition**: the node sits at the bottom
    (`up`) or top (`down`) of the canvas, and all six panels sprout upward/downward from it like
    fruit hanging off branches, matching the game's actual skill-tree visual metaphor better than
    a symmetric radial burst does.
- **Trace routing family**, selected by `traceStyle`, independent of `fanOrient` (deliberately
  decoupled — pick any combination):
  - `straight` — direct line, node to panel corner.
  - `elbow` — one right-angle bend with an optional chamfered corner-cut (`traceCorner`), bend
    position along the line controlled by `traceBend`.
  - `tree` — a bunched vertical "trunk" rising from the node that forks into per-panel
    "branches," reading as a circuit/root structure rather than six independent wires. Within
    `tree`, `sprout` picks the branch's final approach into the panel: `top` (branch rises
    straight up into the panel's bottom-center, subject/fruit-hanging default), `flower` (branch
    bows gently toward the side nearer the node before curving to the panel's near-top corner —
    softer, organic), `outward` (bows further and lands at the panel's *far* top corner instead —
    reads as springing outward/sideways, a harder, more angular result than `flower`). Both
    always land ON the panel's visible top edge — a branch must never appear to run behind or
    into the side of a panel.
  - `none` — panels appear with no connecting trace at all.
- **`traceBend`** (0.15–0.85) is the single shared "where does this line bend" control for both
  `elbow` (bend fraction along the straight run) and `tree`'s `flower`/`outward` sprouts (bend
  fraction along the branch's rise) — deliberately one slider, not two, so tuning stays in one
  place. If in practice `elbow` and `tree` end up wanting different "feel" ranges, split this into
  two exported values in Godot rather than trying to keep the coupling.

## Choreography (the part most worth preserving)
Six **independent** line+panel units, each its own state machine: `hidden → in → loop → out →
hidden`. A unit is staggered only in *when it starts* (`stagger` seconds × its index) — once
started, it runs its own in/hold/out timeline to completion without waiting on any sibling unit.
This is why two panels can visibly be mid-animation while a third is already idling.

- **`syncIn`/`syncOut`** (`sequential` / `simultaneous` / `reverse`) govern the relationship
  between a unit's own line-draw and its own panel-unfurl — not the relationship between units.
  `sequential` = line fully draws in, then panel unfurls (mirrored on exit: panel retracts, then
  line erases). `simultaneous` = both animate together. `reverse` = panel leads, line follows.
- **`entryAnim`** picks the panel's unfurl style: `spring` (default, slight overshoot pop),
  `fan`, `unfoldH`/`unfoldV` (scale from a hinge edge), `decode` (clip-path wipe + an animated
  "electric weld" seam that races along the panel's edge in sync with the wipe), `rise` (fade +
  rise from below).
- **`playMode`**: `auto` runs a full in-hold-out-gap loop forever; `hover` arms the unit chain on
  pointer-enter and reverses it on pointer-leave (a real tooltip's actual trigger).
- **`idleAnim: linger`** is a held-state flourish (gentle floating drift + optional pointer-drag
  spring-back on each settled panel) — an authoring/showcase toy, not tuned game-feel; do not
  port its lerp constants literally (see export notes).

## Design tokens (as authored, hex/OKLCH — convert to Godot `Color` once at build time)
- Owner accent (`archColor`, swappable per node/owner): `#4A96FF` blue / `#F1453E` red /
  `#51C672` green / `#E7BB46` gold / `#B167F7` purple — presented as curated swatches, not a free
  picker, because hue also derives every panel glow color.
- Modifier operator palette (fixed, not owner-tinted): base `#9ED1FF`, `+%` `#F2C76B`, `×`
  `#F28C8C`, bonus `#A6F2B3`, set `#F28CF2`.
- Attribute colors: STR `#F1453E`, DEX `#51C672`, INT `#4A96FF`, WIS `#E7BB46`, PER `#B167F7`.
- Owner/hostile accent (fixed): `oklch(0.72 0.18 25)`-family red. Core badge (fixed): gold,
  `oklch(0.7–0.86 0.13–0.16 88)`-family.
- HP bar: `oklch(0.55 0.2 22)` → `oklch(0.66 0.21 30)` gradient, red glow.
- Canvas background: `radial-gradient(120% 90% at 50% 50%, #0b0d16, #06070d 60%, #030409)`.
- Panel radius 11px (glass) / 8px (solid) / 6px (hologram). Border ~1px at 50% color alpha.
- Type scale: labels 7–9px uppercase/letter-spaced; values 9–13px; owner name 13px Cinzel.

## Motion values (as authored — re-derive as Tween durations, don't copy the numbers verbatim)
- `lineDur` 0.2–1.6s (default 0.5s) — trace draw-in/erase duration.
- `speed` 3–7s (default 4.6s) — drives panel unfurl duration (`speed*0.16`) and hold time
  (`speed*900ms`) before auto-exit; also the loop-chart cycle length.
- `stagger` 0–0.4s (default 0.12s) — per-unit start offset.
- Exit gap ~350ms between a full out-cycle finishing and the next auto-cycle beginning.

## Props reference (current tunable surface)
| Prop | Options / range | Default | Governs |
|---|---|---|---|
| `archColor` | 5 swatches | `#4A96FF` | Owner/node hue → all panel glows |
| `fanOrient` | radial / up / down | `up` | Radial burst vs. tech-tree branch composition |
| `traceStyle` | elbow / straight / tree / none | `tree` | Trace routing family |
| `sprout` | top / flower / outward | `top` | Tree-style branch landing (only matters when `traceStyle=tree`) |
| `traceCorner` | 0–1 | 0.4 | Elbow corner chamfer amount |
| `traceBend` | 0.15–0.85 | 0.5 | Shared bend-position control (elbow bend point / tree branch curve point) |
| `hpPlacement` | ring / header / above / chip | `above` | Where the HP bar surfaces |
| `fanRadius` | 120–230px | 165 | Panel distance from node |
| `fanSpread` | 0.7–1.4 | 1.12 | Panel angular/vertical spacing multiplier |
| `panelSkin` | glass / hologram / solid | `hologram` | Panel surface treatment |
| `modRowStyle` | chip / hologram / bare | `bare` | Granted-modifier row treatment |
| `statChart` | labels / values / both / loop / none | `both` | Radar chart label mode |
| `coreDetail` | badge / class / full | `full` | Core panel verbosity |
| `glow` | 0–1 | 0.8 | Global glow intensity |
| `entryAnim` | fan / spring / unfoldH / unfoldV / decode / rise | `spring` | Panel unfurl style |
| `idleAnim` | static / blink / linger | `static` | Held-state flourish |
| `playMode` | auto / hover | `auto` | Trigger model |
| `traceIdleAnim` | off / spark / pulse | `off` | Loop-state trace accent |
| `lineDur` | 0.2–1.6s | 0.5 | Trace draw duration |
| `syncIn` / `syncOut` | sequential / simultaneous / reverse | `sequential` | Line↔panel entry/exit relationship |
| `loopAnim` | bool | `true` | Whether the auto cycle repeats |
| `speed` | 3–7s | 4.6 | Panel duration + hold time base |
| `stagger` | 0–0.4s | 0.12 | Per-unit start delay |
| `interactive` | bool | `true` | Enables linger drag |
| `simpleCore` | bool | `false` | Swap the ArcheNode import for a plain disc (debug only — always use ArcheNode in-game) |

In Godot this whole surface should become one exported enum/range set on a `TooltipFan` scene
(or resource), matching the grouping above (`Structure` / `Look` / `Motion`) — not six one-off
booleans scattered across the scene tree.

## Interaction & data model
- Trigger: node `PointerEnter`/`PointerLeave` (or hold/select, per the game's actual input model)
  arms `_hoverEnter`/`_hoverLeave`, which just start/reverse the same per-unit chains used by the
  auto-loop — one animation system, two triggers.
- Content is currently **hardcoded sample data** (Granted Modifiers rows, Hostile Owner block,
  radar stat values, Addons, Node-Local loot, Core manifest) — none of it is live-wired. In
  Godot, each panel's content should bind to the real node/owner data model (`StatDef`-driven
  modifier rows, actual owner entity, actual radar stat values) rather than being static per
  scene instance.
- The node itself is rendered via the shared `ArcheNode` component (see `CLAUDE.md` / `ArcheNode
  .dc.html`) — the tooltip is a consumer of that canonical node visual, not its own node style.

## What NOT to copy blindly (see `EXPORT_NOTES_Godot.md` for full detail)
- CSS `@keyframes` percentages, `stroke-dashoffset` SVG line-draw, `oklch()` strings, and the
  JS `setTimeout` chains are all HTML-only implementation details. Re-derive as `Tween`/
  `AnimationPlayer` + `Line2D`/shader + `Color` + signals/coroutines — see the export notes doc
  for the specific substitution for each.
- Variable/prop names here (`sprout`, `traceBend`, `syncIn`, …) are labels for design decisions,
  not required GDScript identifiers — name them per the project's existing style (e.g. match
  `StatDef` / tooltip script naming already in the codebase) as long as the *decision* survives.

## Files
- `CircuitFanTooltip.dc.html` — the component itself (open in a browser; read `renderVals()` in
  its logic class for exact current values/formulas).
- `Circuit Fan Tooltip Lab.dc.html` — the tweak bench used to arrive at the above; useful for
  seeing side-by-side prop combinations, not needed for the port itself.
- `EXPORT_NOTES_Godot.md` — porting-philosophy doc, read alongside this README.
