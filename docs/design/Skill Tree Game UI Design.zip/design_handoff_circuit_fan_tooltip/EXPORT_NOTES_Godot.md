# Export notes — CircuitFanTooltip → Godot

**Read this before porting anything.** This HTML/CSS/JS is a showcase rig for exploring
timing, composition, and visual style — not a spec to transcribe. Copying its variables,
CSS keyframes, or JS timers 1:1 into GDScript has gone wrong before. Ingest the *decisions*,
re-derive the *implementation*, in Godot-native terms.

## What to actually carry over (the ideas, not the code)
- **Per-unit independence**: each of the 6 line+panel pairs is its own state machine
  (`hidden → in → loop → out → hidden`). Stagger only offsets *when* a unit's chain
  starts — once started, a unit never waits on siblings. In Godot: one `Tween` or
  `AnimationPlayer` instance per node/panel pair, kicked off with a per-index delay
  (`get_tree().create_timer(i * stagger)`), not one shared timeline scrubbing all six.
- **syncIn/syncOut** (sequential / simultaneous / reverse): this is just "does the line
  Tween finish before the panel Tween starts, do they start together, or is the order
  swapped." Model literally as which Tween you `await` before starting the next, per unit.
- **lineDur is a duration, not a rate.** Keep it that way — an explicit seconds value per
  segment, composed by whatever plays next, not a speed multiplier baked into a keyframe %.
- **The five visual states per track** (hidden/in/loop/out, plus held/settled) map to
  Tween `finished` signals and an explicit small state enum in script — don't try to
  encode state in animation-position percentages the way the CSS keyframes do.

## What NOT to copy blindly
- **CSS `@keyframes` with hand-tuned percentages** (`14%`, `55%`, `82%`...) bake this
  engine's specific composition into fixed timeline fractions. They will not survive
  being pasted into an `AnimationPlayer` track — rebuild each animation as its own
  Tween with the durations/eases this file settled on, not the percentage layout.
- **`stroke-dashoffset` SVG line-draw** (`cfLineDraw`/`cfTipTravel`) is an HTML/SVG-only
  trick. Godot has no direct equivalent — use `Line2D` with a `Curve`-driven point count,
  or a shader with a progress uniform, to get a "line drawing itself in" look.
  Do not try to find a stroke-dashoffset property in Godot; there isn't one.
- **`oklch(...)` colors** are a CSS color-space convenience. Convert to actual `Color`
  values (sRGB or linear as your pipeline expects) once, at authoring time — don't ship
  an OKLCH string into GDScript and expect it to mean anything.
- **Absolute-position/flex CSS layout** (`position:absolute`, `transform-origin`,
  `translate(-50%,-100%)`) assumes a DOM/CSSOM. In Godot this becomes `Control` anchors/
  margins or `Node2D` positions computed from the same fan-out math — port the *geometry
  formulas* (angles, radii, elbow/tree path logic), not the CSS properties.
- **The JS `setTimeout` chains** (`_at`, `_playInUnit`, etc.) are a plain-JS stand-in for
  what a real engine gives you for free (signals, coroutines, `await tween.finished`).
  Don't recreate a manual timer/callback pyramid in GDScript — use Godot's own primitives.
- **Linger drag physics** (spring-follow + pointer drag in `_startLinger`) is a quick
  showcase flourish, not tuned game-feel. If wanted in-game, redo it as a proper spring/
  input system, not a transplant of the JS lerp constants.

## Practical porting order
1. Nail down the *choreography* (which tracks, which sync mode, which durations) by
   testing presets in the Lab — treat this file as the design reference, not the runtime.
2. In Godot, build one reusable scene for "line + panel unit" with an exported enum for
   sync mode and duration, matching the props here (`syncIn`, `syncOut`, `lineDur`, etc.)
   as `@export` vars.
3. Re-derive each visual (glass/hologram/solid skin, entry animation style, idle loop)
   as its own small Tween/shader recipe — checked against a screenshot of this rig, not
   against its CSS source.
