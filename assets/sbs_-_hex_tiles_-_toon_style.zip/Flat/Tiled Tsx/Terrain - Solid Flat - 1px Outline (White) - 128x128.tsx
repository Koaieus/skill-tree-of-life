<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Terrain - Solid Flat - 1px Outline (White) - 128x128" tilewidth="128" tileheight="128" tilecount="8" columns="4">
 <image source="../Terrain - Solid Flat - 1px Outline (White) - 128x128.png" trans="008080" width="512" height="256"/>
</tileset>
