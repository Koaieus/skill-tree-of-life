<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Terrain - Solid Thick - 1px Outline (Colored) - 128x144" tilewidth="128" tileheight="144" tilecount="16" columns="4">
 <image source="../Terrain - Solid Thick - 1px Outline (Colored) - 128x144.png" trans="008080" width="512" height="576"/>
</tileset>
